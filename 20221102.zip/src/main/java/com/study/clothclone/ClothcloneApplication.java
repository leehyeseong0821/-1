package com.study.clothclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClothcloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClothcloneApplication.class, args);
	}

}
