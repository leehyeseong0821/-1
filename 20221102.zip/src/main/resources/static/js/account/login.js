const registerForwardButton = document.querySelectorAll(".account-button")[1];

registerForwardButton.onclick = () => {
    location.href = "/account/register";
}